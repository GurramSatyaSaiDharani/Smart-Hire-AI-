# Smart Hire AI – AI-Powered Recruitment & Interview Evaluation System

Smart Hire AI is an enterprise AI-powered candidate evaluation, mock interview, and recruitment analytics platform. It automates interview session lifecycles, real-time computer vision telemetry (eye tracking, attention, emotion detection), speech-to-text analysis (grammar, pace, filler words, pronunciation), AI feedback scoring, candidate ranking metrics, weak-area prediction, multi-interview trend analytics, scheduled candidate interviews, and downloadable executive PDF/CSV reports.

---

## 1. Project Overview

Smart Hire AI bridges the gap between candidates preparing for technical interviews and recruiters evaluating talent. Candidates can practice with AI mock interviews, track performance trends across multiple sessions, identify data-driven weak areas, and download comprehensive evaluation reports. Recruiters and administrators get access to candidate rosters, metric-driven candidate ranking algorithms, video recording playbacks, interview scheduling tools, and platform analytics.

---

## 2. Key Features

### Section 8: Dashboard & Analytics
- **Performance Tracking**: Calculates overall score, communication, confidence, technical relevance, professionalism, grammar, pace, filler control, pronunciation, eye-contact ratio, attention index, engagement score, dominant emotion, distraction events count, and total duration.
- **Interview History**: Complete history log of previous candidate interviews with date, start/end time, duration, status, overall score, grade, sub-scores, and AI feedback.
- **Skill-wise Analytics**: Multi-dimensional radar/bar charts evaluating 11 skill categories (Communication, Technical Knowledge, Problem Solving, Confidence, Professionalism, Grammar, Speaking Pace, Pronunciation/Clarity, Eye Contact, Attention, Engagement).
- **Weak-area Prediction**: AI/data-driven weakness identification returning skill name, score, severity (`Critical`, `Needs Improvement`, `Average`, `Good`), analytical reason, and actionable recommendations.
- **Score Breakdown Reports**: Detailed sub-scores and formula weight breakdown:
  $$\text{Overall Score} = (\text{Comm} \times 30\%) + (\text{Conf} \times 25\%) + (\text{Tech} \times 30\%) + (\text{Prof} \times 15\%)$$
- **Performance Trends**: Evaluates multi-interview progress across sessions, calculating trend direction (`Improving`, `Declining`, `Stable`), score deltas, and percentage improvement.
- **Candidate Ranking Metrics**: Recruiter candidate ranking system with sortable metrics (Overall score, Technical, Communication, Confidence, Professionalism).

### Section 9: Notifications & Reports
- **Interview Reminders & Scheduling**: Full scheduling system backed by database table `scheduled_interviews` with statuses (`Scheduled`, `Completed`, `Cancelled`, `Rescheduled`) and automated reminder flags.
- **Email Notifications**: Reusable SMTP email module using environment variables (`EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USERNAME`, `EMAIL_PASSWORD`, `EMAIL_FROM`) with non-crashing development logging fallback.
- **Session Alerts & Toast Notifications**: In-app toast notification system (`toast.js`) replacing plain browser alerts for session events, camera/mic permissions, pause/resume, and distraction flags.
- **Downloadable Executive Reports**: Dynamic PDF generation (ReportLab) and CSV export for individual candidate interview sessions.
- **Performance Summaries**: Automated executive summaries detailing strengths, weak areas, and practice recommendations.

### Section 10: Final Integration & Production Deployment
- End-to-end integration across Auth, Profile, Resume, Jobs, Scheduling, AI Session, Computer Vision Telemetry, Speech Analysis, AI Scoring, Analytics, Weak Areas, Reports, and Notifications.

---

## 3. Technology Stack

- **Backend Framework**: Python 3.10+, FastAPI
- **Web Server**: Uvicorn
- **Database ORM**: SQLAlchemy 2.0+
- **Database Engine**: PostgreSQL (Fallback: SQLite `smart_hire.db`)
- **Authentication**: JWT (`python-jose`)
- **PDF Generation**: ReportLab
- **Frontend Stack**: HTML5, CSS3 (Enterprise Design System), Vanilla JavaScript (ES6+)
- **Charts & Data Visualization**: Chart.js (CDN)
- **Media Acquisition**: WebRTC / HTML5 MediaRecorder (.webm format)

---

## 4. Project Architecture

```
[ Frontend Client ] (Candidate / Recruiter / Admin UI)
        │
        ├── HTTP REST APIs (JSON / Form / Media Uploads)
        ▼
[ FastAPI Backend ] (APP/main.py)
        ├── Auth Router (/register, /login, /profile)
        ├── Session Router (/api/sessions)
        ├── Speech Router (/api/speech-analysis)
        ├── Emotion Router (/api/emotion)
        ├── AI Feedback Router (/api/feedback-scoring)
        ├── Analytics Router (/api/analytics, /api/dashboard)
        ├── Scheduling Router (/api/interviews)
        ├── Notifications Router (/api/notifications)
        └── Reports Router (/api/reports)
        │
        ├── Email Service (APP/email_service.py)
        │
        ▼
[ Database Layer ] (PostgreSQL / SQLite via SQLAlchemy ORM)
```

---

## 5. Folder Structure

```
Smart Hire Ai/
├── APP/
│   ├── __init__.py
│   ├── main.py                     # FastAPI Application Entry Point & Router Registration
│   ├── database.py                 # DB Connection, Engine, SessionLocal & Schema Sync
│   ├── models.py                   # SQLAlchemy Models (User, InterviewSession, InterviewQuestion, ScheduledInterview, Notification)
│   ├── schemas.py                  # Pydantic Request/Response Validation Schemas
│   ├── auth.py                     # Auth Routes (/register, /login, /profile)
│   ├── jwt_handler.py              # JWT Encoding & Verification
│   ├── interview_session.py        # Interview Session Lifecycle & Video Recording Upload
│   ├── speech_analysis.py          # Speech-to-Text, WPM Pace, Grammar & Filler Detection
│   ├── emotion_analysis.py         # Computer Vision Telemetry (Eye Tracking, Attention, Mood)
│   ├── ai_feedback_scoring.py      # Weighted Score Evaluation & AI Feedback Generation
│   ├── analytics.py                # Dashboard APIs, Skill Analytics, Weak Areas & Rankings
│   ├── scheduling.py               # Interview Scheduling & History APIs
│   ├── notifications.py            # Notification Persistence & Endpoint Router
│   ├── email_service.py            # SMTP Email Dispatcher & Dev Logging Fallback
│   └── reports.py                  # Downloadable PDF & CSV Report Generator
├── frontend/
│   ├── index.html                  # Landing Page & Features
│   ├── candidate.html              # Candidate Dashboard (Overview, Trends, Skills, History)
│   ├── recruiter.html              # Recruiter Command Center (Rankings, Scheduled, Vault)
│   ├── admin.html                  # Admin Console (System Overview, Users, Top Rankings)
│   ├── aimockinterview.html        # AI Mock Interview Interface with Webcam & Visualizer
│   ├── schedule_interview.html     # Interview Scheduling Interface & Upcoming Roster
│   ├── view_candidates.html        # Candidate Pool Roster & Performance Profiles
│   ├── view_reports.html           # Recruiter Reports Vault & Video Playback
│   ├── jobs.html                   # Available Job Opportunities
│   ├── post_job.html               # Job Posting Interface
│   ├── upload_resume.html          # Resume Upload Interface
│   ├── loginpage.html              # User Authentication Page
│   ├── register.html               # User Registration Page
│   ├── style.css                   # Enterprise CSS Design System
│   ├── toast.js                    # In-app Toast Notification Engine
│   └── script.js                   # Main Frontend JS Engine & API Integrations
├── uploads/
│   └── recordings/                 # Recorded Video File Archive (.webm)
├── test_analytics_and_reports.py   # Automated End-to-End Test Suite
├── .env                            # Environment Variables (Local)
├── .env.example                    # Environment Template
├── requirements.txt                # Python Dependencies
└── README.md                       # Project Documentation
```

---

## 6. Database Structure

### Tables & Key Attributes

1. `user`: `id`, `username`, `email`, `password`
2. `interview_sessions`: `id`, `session_id`, `interview_id`, `candidate_id`, `candidate_name`, `status`, `start_time`, `end_time`, `total_duration_seconds`, `video_url`, `overall_score`, `overall_grade`, `confidence_score`, `eye_contact_pct`, `attention_score`, `engagement_score`, `dominant_emotion`, `behavior_summary`, `attention_events_count`, `communication_score`, `technical_relevance_score`, `professionalism_score`, `performance_rating`, `ai_feedback_json`, `created_at`
3. `interview_questions`: `id`, `session_id`, `question_index`, `question_text`, `transcript`, `duration_seconds`, `grammar_score`, `pace_score`, `filler_score`, `pronunciation_score`, `created_at`
4. `scheduled_interviews`: `id`, `candidate_id`, `candidate_name`, `candidate_email`, `recruiter_id`, `recruiter_name`, `interview_date`, `interview_time`, `status`, `reminder_status`, `notes`, `created_at`
5. `notifications`: `id`, `user_email`, `title`, `message`, `notification_type`, `is_read`, `created_at`

---

## 7. API Endpoints

### Authentication & Sessions
- `POST /register`: Register new user
- `POST /login`: Authenticate and obtain JWT access token
- `POST /api/sessions/create`: Initialize interview session
- `POST /api/sessions/{session_id}/start`: Start session timer
- `POST /api/sessions/{session_id}/pause`: Pause session
- `POST /api/sessions/{session_id}/resume`: Resume session
- `POST /api/sessions/{session_id}/end`: Finalize session
- `POST /api/sessions/{session_id}/upload-recording`: Upload `.webm` video recording

### Evaluation & Telemetry
- `POST /api/speech-analysis/analyze`: Speech WPM, filler word, and grammar analysis
- `POST /api/emotion/log-telemetry`: Computer vision eye tracking and attention telemetry
- `POST /api/feedback-scoring/evaluate`: Calculate weighted performance scores and AI feedback

### Dashboards & Analytics
- `GET /api/dashboard/candidate`: Candidate performance overview, skills, weak areas, trends, history
- `GET /api/dashboard/recruiter`: Recruiter overview, candidate rankings, scheduled interviews
- `GET /api/dashboard/admin`: System-wide administration metrics and top candidate rankings
- `GET /api/analytics/{candidate_id}/skills`: Skill-wise performance scores (11 skill categories)
- `GET /api/analytics/{candidate_id}/weak-areas`: AI data-driven weak-area predictions
- `GET /api/analytics/{candidate_id}/trends`: Multi-interview trend analysis (Direction, Delta, % Improvement)
- `GET /api/analytics/rankings`: Candidate rankings with configurable metric sorting (`sort_by`)

### Scheduling & Notifications
- `POST /api/interviews/schedule`: Schedule a candidate interview
- `GET /api/interviews/upcoming`: Retrieve list of upcoming scheduled interviews
- `GET /api/interviews/history/{candidate_id}`: Retrieve candidate interview history
- `PUT /api/interviews/{id}`: Update or reschedule interview
- `DELETE /api/interviews/{id}`: Cancel scheduled interview
- `GET /api/notifications`: Retrieve user notifications
- `POST /api/notifications/{id}/read`: Mark notification as read

### Downloadable Reports
- `GET /api/reports/{session_id}`: Full report JSON payload
- `GET /api/reports/{session_id}/pdf`: Generate and download PDF report
- `GET /api/reports/{session_id}/csv`: Generate and download CSV dataset

---

## 8. Installation

1. Navigate to the project root directory:
```bash
cd "C:\Users\Admin\Downloads\Smart Hire Ai"
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

---

## 9. Environment Variables

Create a `.env` file in the project root based on `.env.example`:

```env
DATABASE_URL=sqlite:///./smart_hire.db
# DATABASE_URL=postgresql://postgres:postgres123@localhost:5432/auth_db

SECRET_KEY=mysecretkey123
ALGORITHM=HS256

EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USERNAME=your_email@gmail.com
EMAIL_PASSWORD=your_app_password
EMAIL_FROM=noreply@smarthire.ai
```

---

## 10. How to Run Backend

To start the development server:

```bash
python -m uvicorn APP.main:app --reload --host 127.0.0.1 --port 8000
```

---

## 11. How to Access Frontend

Open your web browser and navigate to:

```
http://127.0.0.1:8000/frontend/index.html
```

---

## 12. Candidate Workflow

1. Navigate to Candidate Portal (`candidate.html`).
2. Review Performance Overview, Skill-wise Analytics (Radar Chart), Weak Areas (AI Predictions), and Performance Trends.
3. Click **"AI Mock Interview"** (`aimockinterview.html`).
4. Enable webcam & microphone, click **"Start Session"**.
5. Speak responses into microphone and click **"Complete Session & Generate AI Feedback"**.
6. Return to candidate dashboard to view updated scores, trend direction, and click **"PDF Report"** or **"CSV Report"** to download session reports.

---

## 13. Recruiter Workflow

1. Access Recruiter Workspace (`recruiter.html`).
2. Review evaluation metrics and top candidate rankings in the Candidate Ranking Table.
3. Sort rankings by Overall Score, Technical Relevance, Communication, Confidence, or Professionalism.
4. Click **"Schedule Interview"** (`schedule_interview.html`) to schedule candidate interviews.
5. Click **"Reports Vault"** (`view_reports.html`) to review candidate video playbacks and download executive PDF/CSV reports.

---

## 14. Admin Workflow

1. Access Admin Console (`admin.html`).
2. Monitor system users, total candidate pool, completed evaluation totals, and average candidate performance.
3. Review platform top-ranked candidates.
4. Manage users (`manage_users.html`) and recruiter permissions (`manage_recruiter.html`).

---

## 15. Automated Testing

To run the automated end-to-end verification test suite:

```bash
python test_analytics_and_reports.py
```

---

## 16. Demonstration Steps for Guide/Judges

1. **Start Backend Server**:
   ```bash
   python -m uvicorn APP.main:app --reload
   ```
2. **Open Application**: Open `http://127.0.0.1:8000/frontend/index.html` in your browser.
3. **Demonstrate AI Mock Interview**:
   - Go to `aimockinterview.html`.
   - Start session, speak answer, and complete session.
   - Show live Section 6 telemetry (Eye contact, attention index, mood) and Section 7 score breakdown.
4. **Demonstrate Section 8 Analytics & Trends**:
   - Go to `candidate.html`. Show skill radar chart, data-driven weak-area prediction cards, and multi-interview performance trends chart.
   - Go to `recruiter.html`. Show candidate ranking table and sort candidates by Technical Relevance Score.
5. **Demonstrate Section 9 Notifications & Reports**:
   - Go to `schedule_interview.html`. Schedule an interview for a candidate. Show in-app notification toast and upcoming scheduled list.
   - Click **"Download PDF Report"** on any session in candidate/recruiter dashboard to demonstrate PDF report generation.
