from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from APP.auth import router as auth_router
from APP.speech_analysis import router as speech_router
from APP.interview_session import router as session_router
from APP.database import engine, Base, sync_db_schema

# Sync DB schema and create missing tables/columns
sync_db_schema()

app = FastAPI(title="Smart Hire AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(speech_router)
app.include_router(session_router)

# Mount static frontend directory
frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))
if os.path.exists(frontend_dir):
    app.mount("/frontend", StaticFiles(directory=frontend_dir, html=True), name="frontend")

# Mount static uploads directory for video recording playback
uploads_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "uploads"))
os.makedirs(uploads_dir, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=uploads_dir), name="uploads")

@app.get("/")
def home():
    return {
        "message": "Smart Hire AI Backend Running",
        "features": [
            "Interview Session Lifecycle (Create, Start, Pause, Resume, End)",
            "Webcam & Microphone Stream Acquisition",
            "MediaRecorder Video & Audio Recording (.webm)",
            "Timer-Based Workflow (Total Duration, Question Time, Countdown)",
            "Speech-to-Text & Communication Analysis Suite",
            "Recruiter Reports Vault & Video Playback"
        ],
        "frontend_url": "http://127.0.0.1:8000/frontend/index.html"
    }