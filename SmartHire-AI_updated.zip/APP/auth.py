from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from APP.database import SessionLocal
from APP.models import User
from APP.schemas import UserCreate, UserLogin
from APP.jwt_handler import create_access_token

router = APIRouter()

security = HTTPBearer()


@router.post("/register")
def register(user: UserCreate):

    db = SessionLocal()

    try:

        # Check if email already exists
        existing_user = db.query(User).filter(
            User.email == user.email
        ).first()

        if existing_user:
            return {
                "message": "Email already registered"
            }

        # Create new user
        new_user = User(
            username=user.username,
            email=user.email,
            password=user.password
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return {
            "message": "User Registered Successfully",
            "username": new_user.username
        }

    except Exception as e:

        db.rollback()

        return {
            "message": "Registration Failed",
            "error": str(e)
        }

    finally:
        db.close()


@router.post("/login")
def login(user: UserLogin):

    db = SessionLocal()

    try:

        db_user = db.query(User).filter(
            User.email == user.email
        ).first()

        if not db_user:
            return {
                "message": "User Not Found"
            }

        if db_user.password != user.password:
            return {
                "message": "Incorrect Password"
            }

        token = create_access_token(
            {
                "sub": db_user.email
            }
        )

        return {
            "message": "Login Successful",
            "username": db_user.username,
            "email": db_user.email,
            "access_token": token,
            "token_type": "bearer"
        }

    finally:
        db.close()


@router.get("/profile")
def profile(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):

    return {
        "message": "Welcome! You are an authenticated user.",
        "token": credentials.credentials
    }