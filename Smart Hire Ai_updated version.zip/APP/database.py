from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv
import os

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
print("DATABASE_URL =", DATABASE_URL)

try:
    if DATABASE_URL:
        engine = create_engine(DATABASE_URL)
        # Test connection
        with engine.connect() as conn:
            pass
    else:
        raise Exception("No DATABASE_URL provided")
except Exception as e:
    print(f"PostgreSQL connection failed ({e}). Falling back to SQLite.")
    DATABASE_URL = "sqlite:///./smart_hire.db"
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()

def sync_db_schema():
    Base.metadata.create_all(bind=engine)
    try:
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        if "interview_sessions" in tables:
            columns = [c["name"] for c in inspector.get_columns("interview_sessions")]
            with engine.begin() as conn:
                if "candidate_name" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN candidate_name VARCHAR(100) DEFAULT 'Candidate'"))
                if "video_url" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN video_url VARCHAR(255)"))
                if "overall_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN overall_score FLOAT"))
                if "overall_grade" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN overall_grade VARCHAR(10)"))
                if "total_duration_seconds" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN total_duration_seconds FLOAT DEFAULT 0.0"))
                if "status" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN status VARCHAR(50) DEFAULT 'CREATED'"))
                if "start_time" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN start_time TIMESTAMP"))
                if "end_time" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN end_time TIMESTAMP"))
                if "confidence_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN confidence_score FLOAT"))
                if "eye_contact_pct" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN eye_contact_pct FLOAT"))
                if "attention_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN attention_score FLOAT"))
                if "engagement_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN engagement_score FLOAT"))
                if "dominant_emotion" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN dominant_emotion VARCHAR(50)"))
                if "emotion_breakdown_json" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN emotion_breakdown_json TEXT"))
                if "behavior_summary" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN behavior_summary TEXT"))
                if "attention_events_count" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN attention_events_count INTEGER DEFAULT 0"))
                if "communication_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN communication_score FLOAT"))
                if "technical_relevance_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN technical_relevance_score FLOAT"))
                if "professionalism_score" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN professionalism_score FLOAT"))
                if "performance_rating" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN performance_rating VARCHAR(50)"))
                if "ai_feedback_json" not in columns:
                    conn.execute(text("ALTER TABLE interview_sessions ADD COLUMN ai_feedback_json TEXT"))
    except Exception as e:
        print("Schema sync notice:", e)