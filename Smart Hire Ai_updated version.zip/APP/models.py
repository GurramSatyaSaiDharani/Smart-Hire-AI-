from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from datetime import datetime
from APP.database import Base

class User(Base):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password = Column(String(255), nullable=False)


class InterviewSession(Base):
    __tablename__ = "interview_sessions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(100), unique=True, index=True, nullable=False)
    interview_id = Column(Integer, nullable=True, default=1)
    candidate_id = Column(Integer, nullable=True, default=1)
    candidate_name = Column(String(100), default="Candidate")
    status = Column(String(50), default="CREATED")  # CREATED, IN_PROGRESS, PAUSED, COMPLETED
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    total_duration_seconds = Column(Float, default=0.0)
    video_url = Column(String(255), nullable=True)
    overall_score = Column(Float, nullable=True)
    overall_grade = Column(String(10), nullable=True)
    confidence_score = Column(Float, nullable=True)
    eye_contact_pct = Column(Float, nullable=True)
    attention_score = Column(Float, nullable=True)
    engagement_score = Column(Float, nullable=True)
    dominant_emotion = Column(String(50), nullable=True)
    emotion_breakdown_json = Column(Text, nullable=True)
    behavior_summary = Column(Text, nullable=True)
    attention_events_count = Column(Integer, default=0)
    communication_score = Column(Float, nullable=True)
    technical_relevance_score = Column(Float, nullable=True)
    professionalism_score = Column(Float, nullable=True)
    performance_rating = Column(String(50), nullable=True)
    ai_feedback_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class InterviewQuestion(Base):
    __tablename__ = "interview_questions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(100), index=True, nullable=False)
    question_index = Column(Integer, nullable=False)
    question_text = Column(String(500), nullable=False)
    transcript = Column(Text, nullable=True)
    duration_seconds = Column(Float, default=0.0)
    grammar_score = Column(Float, nullable=True)
    pace_score = Column(Float, nullable=True)
    filler_score = Column(Float, nullable=True)
    pronunciation_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)