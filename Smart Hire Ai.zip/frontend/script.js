const API = "http://127.0.0.1:8000";

async function register() {

    const data = {
        username: document.getElementById("username").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    };

    const response = await fetch(API + "/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    const result = await response.json();

    document.getElementById("registerResult").innerHTML = result.message;

    if (result.message === "User Registered Successfully") {
        setTimeout(() => {
            window.location.href = "loginpage.html";
        }, 1000);
    }
}

async function handleLogin() {

    const data = {
        email: document.getElementById("loginEmail").value,
        password: document.getElementById("loginPassword").value
    };

    const response = await fetch(API + "/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    const result = await response.json();

    if (result.access_token) {

        localStorage.setItem("token", result.access_token);
        localStorage.setItem("username", result.username);

        const role = document.getElementById("loginRole").value;

        if (role === "candidate") {
            window.location.href = "candidate.html";
        } else if (role === "recruiter") {
            window.location.href = "recruiter.html";
        } else {
            window.location.href = "admin.html";
        }

    } else {
        document.getElementById("message").innerHTML = result.message;
    }
}