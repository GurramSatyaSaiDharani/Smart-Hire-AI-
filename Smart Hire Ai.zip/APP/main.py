from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from APP.auth import router
from APP.database import engine, Base

Base.metadata.create_all(bind=engine)

app = FastAPI()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(router)


@app.get("/")
def home():
    return {
        "message": "Smart Hire Backend Running"
    }